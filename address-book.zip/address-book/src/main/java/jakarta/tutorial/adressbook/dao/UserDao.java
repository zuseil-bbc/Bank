package jakarta.tutorial.adressbook.dao;

import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import jakarta.tutorial.addressbook.entity.Customer;

@RequestScoped
public class UserDao {

	@PersistenceContext
	private EntityManager em;

	public List<Customer> findAllCustomers() {
		return em.createNamedQuery("findAllCustomers", Customer.class).getResultList();

	}
	
	public Customer findByCustomerNr(String customerNr) {
		return em.createNamedQuery("findByCustomerNr", Customer.class).setParameter("customer_number", customerNr).getSingleResult();
	}
}
