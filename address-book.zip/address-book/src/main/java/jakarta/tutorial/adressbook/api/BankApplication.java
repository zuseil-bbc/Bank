package jakarta.tutorial.adressbook.api;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/")
public class BankApplication extends Application {
	
	

}
