package jakarta.tutorial.adressbook.api;

import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;

import jakarta.tutorial.addressbook.entity.Account;
import jakarta.tutorial.adressbook.dao.AccountDao;
import jakarta.tutorial.adressbook.dto.DepositDto;

@Path("deposit")
public class DepositController {

	@Inject
	AccountDao accountDao;

	@POST
	public void Deposit(DepositDto depositDto) {

		Account account = accountDao.findByIban(depositDto.selectedAccount);

		float newBalance = depositDto.amount + account.getBalance();

		account.setBalance(newBalance);

		accountDao.saveAccount(account);

	}

}
