package jakarta.tutorial.adressbook.api;

import java.io.IOException;
import java.util.ArrayList;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.tutorial.adressbook.dao.UserDao;
import jakarta.tutorial.adressbook.dto.UserDto;

@Path("transaction")
public class TransactionController {
	
	@Inject
	UserDao userDao;

	@POST
	@Produces("text/json")
	public String userList() {
		ObjectMapper obj = new ObjectMapper();

		ArrayList<UserDto> userDtoList = userDao.findAllCustomers().stream().map(customer -> {
			return new UserDto(customer.getFirst_name(), customer.getLast_name(), customer.getCustomer_number());
		}).collect(Collectors.toCollection(ArrayList::new));

		String jsonStr = "";
		try {
			jsonStr = obj.writeValueAsString(userDtoList);

		} catch (IOException e) {
			e.printStackTrace();
		}
		return jsonStr;
	}

}
