package jakarta.tutorial.adressbook.dto;

public class UserDto {

	private String firstName;
	private String lastName;
	private String customerNr;

	public UserDto(String firstName, String lastName, String customerNr) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.customerNr = customerNr;

	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCustomerNr() {
		return customerNr;
	}

	public void setCustomerNr(String customerNr) {
		this.customerNr = customerNr;
	}
}
