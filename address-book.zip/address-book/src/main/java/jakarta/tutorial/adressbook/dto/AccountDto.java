package jakarta.tutorial.adressbook.dto;

import jakarta.tutorial.addressbook.entity.Customer;

public class AccountDto {

	private String iban;
	private float balance;
	private float overdraft;

	private Customer customer;

	public AccountDto(String iban, float balance, Customer customer, float overdraft) {
		this.iban = iban;
		this.balance = balance;
		this.customer = customer;
		this.overdraft = overdraft;
	}

	public String getIban() {
		return iban;
	}

	public void setIban(String iban) {
		this.iban = iban;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public float getOverdraft() {
		return overdraft;
	}

	public void setOverdraft(float overdraft) {
		this.overdraft = overdraft;
	}

}
