package jakarta.tutorial.adressbook.dto;

public class DepositDto {
	
	public String selectedAccount;
	public float amount;
	
	
	

}
