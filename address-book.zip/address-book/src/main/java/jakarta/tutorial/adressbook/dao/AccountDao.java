package jakarta.tutorial.adressbook.dao;

import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import jakarta.tutorial.addressbook.entity.Account;
import jakarta.tutorial.addressbook.entity.Customer;

@RequestScoped
@Transactional
public class AccountDao {

	@PersistenceContext
	private EntityManager em;

	public List<Account> findAllAccounts() {
		return em.createNamedQuery("findAllAccounts", Account.class).getResultList();

	}

	public List<Account> findByCustomer(Customer customer) {

		return em.createNamedQuery("findByCustomer", Account.class).setParameter("customer", customer).getResultList();

	}

	public Account findByIban(String iban) {

		return em.createNamedQuery("findByIban", Account.class).setParameter("iban", iban).getSingleResult();

	}
	
	public void saveAccount(Account account) {
		try {
			boolean test = em.contains(account);
			em.merge(account);
			em.flush();
		}
		catch (Exception e) {
			e.printStackTrace();
		}		
	
	}

}
