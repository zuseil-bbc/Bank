package jakarta.tutorial.adressbook.api;

import java.io.IOException;
import java.util.ArrayList;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.tutorial.addressbook.entity.Customer;
import jakarta.tutorial.adressbook.dao.AccountDao;
import jakarta.tutorial.adressbook.dao.UserDao;
import jakarta.tutorial.adressbook.dto.AccountDto;

@Path("account/list")
public class AccountListController {
	
	@Inject
	UserDao userDao;
	
	@Inject
	AccountDao accountDao;
	
	@GET
	@Produces("text/json")
	@Path("{customerNr}")
	public String AccountList(@PathParam("customerNr") String customerNr) {
		
		ObjectMapper obj = new ObjectMapper();

		Customer customer = userDao.findByCustomerNr(customerNr); 
		
		ArrayList<AccountDto> accountDtoList = accountDao.findByCustomer(customer).stream().map(account -> {
			return new AccountDto(account.getIban(), account.getBalance(), account.getCustomer(), account.getOverdraft());
		}).collect(Collectors.toCollection(ArrayList::new));

		String jsonStr = "";
		try {
			jsonStr = obj.writeValueAsString(accountDtoList);

		} catch (IOException e) {
			e.printStackTrace();
		}
		return jsonStr;
		
	}
	

}
