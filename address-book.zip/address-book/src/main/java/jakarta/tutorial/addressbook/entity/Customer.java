package jakarta.tutorial.addressbook.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

@Entity
@NamedQueries({ @NamedQuery(name = "findAllCustomers", query = "SELECT c from Customer c"),
		@NamedQuery(name = "findByCustomerNr", query = "SELECT c from Customer c WHERE c.customer_number = :customer_number")

})
public class Customer {
	@Id
	private int id;
	private String customer_number;
	private String title;
	private String first_name;
	private String last_name;
	private String street;
	private String city;
	private int zipcode;

	public Customer() {
	}

	public Customer(int id, String customer_number, String title, String first_name, String last_name, String street,
			String city, int zipcode) {
		this.id = id;
		this.customer_number = customer_number;
		this.title = title;
		this.first_name = first_name;
		this.last_name = last_name;
		this.street = street;
		this.city = city;
		this.zipcode = zipcode;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCustomer_number() {
		return customer_number;
	}

	public void setCustomer_number(String customer_number) {
		this.customer_number = customer_number;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getZipcode() {
		return zipcode;
	}

	public void setZipcode(int zipcode) {
		this.zipcode = zipcode;
	}

}
