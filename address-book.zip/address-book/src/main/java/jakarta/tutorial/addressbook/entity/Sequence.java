package jakarta.tutorial.addressbook.entity;

import javax.persistence.Id;

public class Sequence {

	@Id
	private String seq_name;
	private float decimal;
	
	public Sequence() {}

	public Sequence(String seq_name, float decimal) {
		this.seq_name = seq_name;
		this.decimal = decimal;
	}

	public String getSeq_name() {
		return seq_name;
	}

	public void setSeq_name(String seq_name) {
		this.seq_name = seq_name;
	}

	public float getDecimal() {
		return decimal;
	}

	public void setDecimal(float decimal) {
		this.decimal = decimal;
	}

}
