package jakarta.tutorial.addressbook.entity;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class TransactionRecord {
	@Id
	private int id;
	private String type;
	private String text;
	private float amount;
	private Date transaction_time;
	private int account_id;

	public TransactionRecord(){
		
	}

	public TransactionRecord(int id, String type, String text, float amount, Date transaction_time, int account_id) {
		this.id = id;
		this.type = type;
		this.text = text;
		this.amount = amount;
		this.transaction_time = transaction_time;
		this.account_id = account_id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	public Date getTransaction_time() {
		return transaction_time;
	}

	public void setTransaction_time(Date transaction_time) {
		this.transaction_time = transaction_time;
	}

	public int getAccount_id() {
		return account_id;
	}

	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}

}
